package Controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.SQLException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ResourceBundle;

import application.Database;
import application.sendmail;
import application.temp;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

public class IncomesCont {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField amounttxt;

    @FXML
    private TextField fromtxt;

    @FXML
    private Button h;

    @FXML
    private Button inc;

    @FXML
    private Button out;

    @FXML
    private Button lin;

    @FXML
    private Button lout;

    @FXML
    private Button logout;

    @FXML
    private Button sub;

    @FXML
    private DatePicker date;

    @FXML
    private TextField name;

    @FXML
    private RadioButton temp;

    @FXML
    private ToggleGroup gtype;

    @FXML
    private RadioButton perm;

    @FXML
    private TextArea bill;

    @FXML
    private Button p;

 
    @FXML
    private ComboBox<?> ccat;

  

    Models.Incomemodel in;
    Database d=new Database();
   	ObservableList oblist = FXCollections.observableArrayList();
    @FXML
    void submit(ActionEvent event)  throws SQLException  {
    	
    	String dd=date.getValue().toString();
    	if( name.getText().isEmpty() ||amounttxt.getText().isEmpty()|| fromtxt.getText().isEmpty()|| (temp.getText().isEmpty() && perm.getText().isEmpty()) ||ccat.getValue()==null  || dd.isEmpty())
    	{
 		
   		 Alert a = new Alert(AlertType.NONE);
  		  a.setAlertType(AlertType.ERROR);
  		  a.setContentText("Empty Fields");
              a.show();
    	}
    	else
    	{	
    		RadioButton selectedRadioButton = (RadioButton) gtype.getSelectedToggle();
    		String t = selectedRadioButton.getText();	
    		bill.setText("\tBill System:\n"+
    				"===================================\n"+
 				"\tFrom:\t\t"+fromtxt.getText()+"\n"+
 				"\tAmount:\t\t"+amounttxt.getText()+"\n"+
 				"\tCategory:\t\t"+ccat.getValue()+"\n"+
 				"=================================\n"+
 				"\tDate:\t\t"+dd
 				);
    		temp temp =new temp() ;
    		if(temp.getflagIncome()==0)
			{
    			in=new Models.Incomemodel("",name.getText(),amounttxt.getText(),fromtxt.getText(),ccat.getValue().toString(), t, dd);
    			in.insert();
    			in.mail(bill.getText());
			}else if(temp.getflagIncome()==1)
			{
				 ObservableList <Models.Incomemodel> O= temp.getIncome();
				 Models.Incomemodel tt=O.get(0);
				
				 in=new Models.Incomemodel("",name.getText(),amounttxt.getText(),fromtxt.getText(),ccat.getValue().toString(), t, dd);
				 in.update(tt.getName(),tt.getAmount());
			}
    			
    	}
    }
    @FXML
    void Home(ActionEvent event) throws IOException {
    	Stage s = (Stage) h.getScene().getWindow();
      	 s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/Home.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("Home");
		  stage.show();
    }
    
    @FXML
    void income(ActionEvent event) {

    }

    @FXML
    void listin(ActionEvent event) throws IOException {
    	Stage s = (Stage) lin.getScene().getWindow();
      	 s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/listincome.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("listofincome");
		  stage.show();
    }

    @FXML
    void listout(ActionEvent event) throws IOException {
    	Stage s = (Stage) lout.getScene().getWindow();
     	 s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/listoutcome.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("listofoutcome");
		  stage.show();
    }

    @FXML
    void logout(ActionEvent event) throws IOException {
    	Stage s = (Stage) logout.getScene().getWindow();
   	 s.close();
   	Parent parent=FXMLLoader.load(getClass().getResource("/Views/login.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("Login");
		  stage.show();
    }

    @FXML
    void outcome(ActionEvent event) throws IOException {
    	Stage s = (Stage) out.getScene().getWindow();
      	 s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/Outcome.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("Outcome");
		  stage.show();
    }

    @FXML
    void print(ActionEvent event) {
    	
    }

  
   
    @FXML
    void initialize() throws SQLException {
    	oblist=d.getcat(3, "Income", "","");
     	ccat.setItems(oblist);
    	 gtype=new ToggleGroup();
         temp.setToggleGroup(gtype);
         perm.setToggleGroup(gtype);
         
         
    }
}
