package Controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import Models.Outcomemodel;
import application.Database;
import application.temp;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class listincomeCont {

	@FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button h;

    @FXML
    private Button in;

    @FXML
    private Button outc;

    @FXML
    private Button lout;
    @FXML
    private Button updatedata;
    @FXML
    private TableView<Models.Incomemodel> Itab;

    @FXML
    private TableColumn<Models.Incomemodel, String> Colname;

    @FXML
    private TableColumn<Models.Incomemodel, String> Colamount;

    @FXML
    private TableColumn<Models.Incomemodel, String> Colfrom;

    @FXML
    private TableColumn<Models.Incomemodel, String> Colto;

    @FXML
    private TableColumn<Models.Incomemodel, String> Coltype;

    @FXML
    private TableColumn<Models.Incomemodel, String> Colpartnum;

    @FXML
    private TableColumn<Models.Incomemodel, String> Colcat;
    @FXML
    private TableColumn<Models.Incomemodel, String> Coldate;
    @FXML
    private Button logout;

    @FXML
    private Button loaddata;

    @FXML
    private DatePicker D1;

    @FXML
    private DatePicker D2;
    

    @FXML
    private Button export;
    
    @FXML
    private ComboBox<String> cat;
    
    Database d=new Database();
    Models.listincomemodel lm=new Models.listincomemodel();
    ObservableList oblist = FXCollections.observableArrayList();
    ObservableList <Models.Incomemodel> ol= FXCollections.observableArrayList();
    @FXML
    void Load(ActionEvent event) throws SQLException {
    	 String dd1=D1.getValue().toString();
    	 String dd2=D2.getValue().toString();
     	if( dd1.isEmpty() || dd2.isEmpty())
     	{
    		 Alert a = new Alert(AlertType.NONE);
   		  a.setAlertType(AlertType.ERROR);
   		  a.setContentText("Empty Fields");
               a.show();
     	}
     	else
     	{
     		Colname.setCellValueFactory(new PropertyValueFactory<>("name"));
     		Colamount.setCellValueFactory(new PropertyValueFactory<>("amount"));
     		Colfrom.setCellValueFactory(new PropertyValueFactory<>("from"));
     		Coltype.setCellValueFactory(new PropertyValueFactory<>("type"));
     		Coldate.setCellValueFactory(new PropertyValueFactory<>("date"));
     		Colcat.setCellValueFactory(new PropertyValueFactory<>("cat"));
     		Colpartnum.setCellValueFactory(new PropertyValueFactory<>("partnum"));
    		Itab.setItems(lm.list(cat.getSelectionModel().getSelectedItem().toString(),dd1, dd2));
    		
     	}
    }
    @FXML
    void clicked(MouseEvent event) {
    	
    	if(event.getClickCount()==1)
    	{	
    	ol.clear();
    	Models.Incomemodel temp=Itab.getSelectionModel().getSelectedItem();
    	ol.add(temp);
    	}
    }
    
    @FXML
    void update(ActionEvent event) throws IOException {
    	temp t=new temp();
		t.setIncome(ol);
		t.setflagIncome(1);
    	Stage s = (Stage) updatedata.getScene().getWindow();
     	 s.close();
     	Parent parent=FXMLLoader.load(getClass().getResource("/Views/Income.fxml"));
  		  Stage stage=new Stage();
  		  stage.setScene(new Scene(parent));
  		  stage.setTitle("Update");
  		  stage.show();
    }
    @FXML
    void Home(ActionEvent event) throws IOException {
    	Stage s = (Stage) h.getScene().getWindow();
      	 s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/Home.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("Home");
		  stage.show();
    }
    
    @FXML
    void income(ActionEvent event) throws IOException {
    	Stage s = (Stage) in.getScene().getWindow();
     	 s.close();
   	Parent parent=FXMLLoader.load(getClass().getResource("/Views/Income.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("Income");
		  stage.show();
    }

    @FXML
    void listin(ActionEvent event) throws IOException {
//    	Stage s = (Stage) lin.getScene().getWindow();
//      	 s.close();
//    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/listincome.fxml"));
//		  Stage stage=new Stage();
//		  stage.setScene(new Scene(parent));
//		  stage.setTitle("listofincome");
//		  stage.show();
    }

    @FXML
    void listout(ActionEvent event) throws IOException {
    	Stage s = (Stage) lout.getScene().getWindow();
     	 s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/listoutcome.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("listofoutcome");
		  stage.show();
    }

    @FXML
    void logout(ActionEvent event) throws IOException {
    	Stage s = (Stage) logout.getScene().getWindow();
   	 s.close();
   	Parent parent=FXMLLoader.load(getClass().getResource("/Views/login.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("Login");
		  stage.show();
    }

    @FXML
    void outcome(ActionEvent event) throws IOException {
    	Stage s = (Stage) outc.getScene().getWindow();
      	 s.close();
      	Parent parent=FXMLLoader.load(getClass().getResource("/Views/Outcome.fxml"));
   		  Stage stage=new Stage();
   		  stage.setScene(new Scene(parent));
   		  stage.setTitle("Outcome");
   		  stage.show();
    }

    @FXML
    void exportexcel(ActionEvent event) throws IOException {
    	lm.export();
    }

    @FXML
    void initialize() throws SQLException {
    	oblist=d.getcat(3, "Income", "All","");
     	cat.setItems(oblist);
    }
}
