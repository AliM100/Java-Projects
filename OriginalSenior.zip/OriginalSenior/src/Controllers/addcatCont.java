package Controllers;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class addcatCont {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField desc;

    @FXML
    private TextField money;

    @FXML
    private Button sub;

    @FXML
    private TextField code;

    @FXML
    private TextField level;

    @FXML
    private TextField type;
    Models.addcatmodel b;
    @FXML
    void submit(ActionEvent event) throws SQLException {

    	
    	if(code.getText().isEmpty() ||  desc.getText().isEmpty() || money.getText().isEmpty() || level.getText().isEmpty() || type.getText().isEmpty())
    	{
 		
   		 Alert a = new Alert(AlertType.NONE);
  		  a.setAlertType(AlertType.ERROR);
  		  a.setContentText("Empty Fields");
              a.show();
    	}
    	else
    	{	
    		
    			b=new Models.addcatmodel(code.getText(),desc.getText(),level.getText(),type.getText(),money.getText());
    			b.insert();
    			
    	}
    }

    @FXML
    void initialize() {
       

    }
}
