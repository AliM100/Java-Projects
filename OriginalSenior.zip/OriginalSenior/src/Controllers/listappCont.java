package Controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import Models.Outcomemodel;
import Models.addappmodel;
import Models.sendingmailmodel;

import application.temp;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Dialog;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class listappCont {

	@FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button h;


    @FXML
    private Button in;

    @FXML
    private Button outc;
    @FXML
    private Button lout;

    @FXML
    private Button lin;

    @FXML
    private TableView<Models.addappmodel> Itab;

    @FXML
    private TableColumn<Models.addappmodel, String> Colname;

    @FXML
    private TableColumn<Models.addappmodel, String> Coltel;

    @FXML
    private TableColumn<Models.addappmodel, String> Colemail;

    @FXML
    private TableColumn<Models.addappmodel, String> Colisadmin;

    @FXML
    private TableColumn<Models.addappmodel, String> colapart;

    @FXML
    private TableColumn<Models.addappmodel, String> colblocknum;

    @FXML
    private TableColumn<Models.addappmodel, String> colatype;

    @FXML
    private TableColumn<Models.addappmodel, String> colaname2;

    @FXML
    private TableColumn<Models.addappmodel, String> colatel2;

    @FXML
    private TableColumn<Models.addappmodel, String> colaemail2;

    @FXML
    private TableColumn<Models.addappmodel,String> colmoney;
   
    @FXML
    private Button sendemail;
//    @FXML
//    private TableColumn<Models.addappmodel, String> Coldate;
    @FXML
    private Button logout;

    @FXML
    private Button loaddata;
    @FXML
    private Button export;
    @FXML
    private Button sendAllbtn;
    @FXML
    private Button updatedata;

//    @FXML
//    private DatePicker D1;
//
//    @FXML
//    private DatePicker D2;

    Models.listappmodel lm=new Models.listappmodel();
	ObservableList <Models.addappmodel> ol= FXCollections.observableArrayList();
	ObservableList <Models.addappmodel> O= FXCollections.observableArrayList();
    @FXML
    void Load(ActionEvent event) throws SQLException {
//    	 String dd1=D1.getValue().toString();
//    	 String dd2=D2.getValue().toString();
//     	if( dd1.isEmpty() || dd2.isEmpty())
//     	{
//    		 Alert a = new Alert(AlertType.NONE);
//   		  a.setAlertType(AlertType.ERROR);
//   		  a.setContentText("Empty Fields");
//               a.show();
//     	}
//     	else
//     	{
     		Colname.setCellValueFactory(new PropertyValueFactory<>("name"));
     		Coltel.setCellValueFactory(new PropertyValueFactory<>("tel"));
     		Colemail.setCellValueFactory(new PropertyValueFactory<>("email"));
     		Colisadmin.setCellValueFactory(new PropertyValueFactory<>("isadmin"));
     		colapart.setCellValueFactory(new PropertyValueFactory<>("partnum"));
     		colblocknum.setCellValueFactory(new PropertyValueFactory<>("blockrealnum"));
     		colatype.setCellValueFactory(new PropertyValueFactory<>("type"));
     		colaname2.setCellValueFactory(new PropertyValueFactory<>("rname"));
     		colatel2.setCellValueFactory(new PropertyValueFactory<>("rtel"));
     		colaemail2.setCellValueFactory(new PropertyValueFactory<>("remail"));
     		colmoney.setCellValueFactory(new PropertyValueFactory<>("moneyneeded"));
     		//Coldate.setCellValueFactory(new PropertyValueFactory<>("date"));
     		 	Itab.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
     		 	O=lm.list();
     		 	
     			Itab.setItems(O);
 
    //}
     	//}
    }
    @FXML
    void exportexcel(ActionEvent event) throws IOException {
    	lm.export();
    }

    @FXML
    void Home(ActionEvent event) throws IOException {
    	Stage s = (Stage) h.getScene().getWindow();
      	 s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/Home.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("Home");
		  stage.show();
    }
    
    @FXML
    void income(ActionEvent event) throws IOException {
    	Stage s = (Stage) in.getScene().getWindow();
     	 s.close();
   	Parent parent=FXMLLoader.load(getClass().getResource("/Views/Income.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("Income");
		  stage.show();
    }

    @FXML
    void listin(ActionEvent event) throws IOException {
    	Stage s = (Stage) lin.getScene().getWindow();
      	 s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/listincome.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("listofincome");
		  stage.show();
    }

    @FXML
    void listout(ActionEvent event) throws IOException {
    	Stage s = (Stage) lout.getScene().getWindow();
     	 s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/listoutcome.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("listofoutcome");
		  stage.show();
    }

    @FXML
    void logout(ActionEvent event) throws IOException {
    	Stage s = (Stage) logout.getScene().getWindow();
   	 s.close();
   	Parent parent=FXMLLoader.load(getClass().getResource("/Views/login.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("Login");
		  stage.show();
    }

    @FXML
    void outcome(ActionEvent event) throws IOException {
    	Stage s = (Stage) outc.getScene().getWindow();
      	 s.close();
      	Parent parent=FXMLLoader.load(getClass().getResource("/Views/Outcome.fxml"));
   		  Stage stage=new Stage();
   		  stage.setScene(new Scene(parent));
   		  stage.setTitle("Outcome");
   		  stage.show();
    }

    @FXML
    void send(ActionEvent event) throws IOException {
    	
		 
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/writetexttomail.fxml"));
    	
 		  Stage stage=new Stage();
 		  temp t=new temp();
 		  t.setO(ol);
 		  stage.setScene(new Scene(parent));
 		  stage.setTitle("Sending Email");
 		  stage.show();
    	 
    }
    @FXML
    void sendAll(ActionEvent event) throws IOException {
    	
   	Parent parent=FXMLLoader.load(getClass().getResource("/Views/writetexttomail.fxml"));
   		
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("Sending Email");
		  temp t=new temp();
			t.setO(O);
			
		  stage.show();
    }
    @FXML
    void isselected(MouseEvent event) {
    	Models.addappmodel temp=Itab.getSelectionModel().getSelectedItem();
    	ol.add(temp);
    
    }
    @FXML
    void update(ActionEvent event) throws IOException {
    	 
    	temp t=new temp();
		t.setO(ol);
		t.setflag(1);
    	Stage s = (Stage) updatedata.getScene().getWindow();
     	 s.close();
     	Parent parent=FXMLLoader.load(getClass().getResource("/Views/addapp.fxml"));
  		  Stage stage=new Stage();
  		  stage.setScene(new Scene(parent));
  		  stage.setTitle("Update");
  		  stage.show();
    }

    @FXML
    void initialize() {
    	
    }
}
