package Controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class HomeCont {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button lpeople;

    @FXML
    private Button outcome;

    @FXML
    private Button income;

    @FXML
    private Button logout;

    @FXML
    private Button lother;

    @FXML
    private Button lin;

    @FXML
    private Button lout;

    @FXML
    private Button oth;

    @FXML
    private Label money;

    @FXML
    private Button app;
    @FXML
    private Button block;
    @FXML
    private Button report;
    @FXML
    private Button cat;
    @FXML
    private Button lblock;
    @FXML
    private Button listpaid;

    @FXML
    void addcat(ActionEvent event) throws IOException {
    	
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/addcat.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("addcat");
		  stage.show();
    }
    @FXML
    void addapp(ActionEvent event) throws IOException {
    	Stage s = (Stage) app.getScene().getWindow();
		s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/addapp.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("addapp");
		  stage.show();
    }

    @FXML
    void addblock(ActionEvent event) throws IOException {
    	
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/addblock.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("addblock");
		  stage.show();
    }
    @FXML
    void addoth(ActionEvent event) throws IOException {
    	Stage s = (Stage) app.getScene().getWindow();
		s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/addoth.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("addoth");
		  stage.show();
    }

    @FXML
    void inc(ActionEvent event) throws IOException {
    	Stage s = (Stage) income.getScene().getWindow();
		s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/Income.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("Income");
		  stage.show();
    }

    @FXML
    void listother(ActionEvent event) throws IOException {
    	Stage s = (Stage) lother.getScene().getWindow();
		s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/listother.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("listother");
		  stage.show();
    }

    @FXML
    void listpeople(ActionEvent event) throws IOException {
    	Stage s = (Stage) lpeople.getScene().getWindow();
    		s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/listofapp.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("listpeople");
		  stage.show();
    }

    @FXML
    void log(ActionEvent event) throws IOException {
    	Stage s = (Stage) logout.getScene().getWindow();
    	 s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/login.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("Login");
		  stage.show();
    }

    @FXML
    void outc(ActionEvent event) throws IOException {
    	Stage s = (Stage) outcome.getScene().getWindow();
   	 	s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/Outcome.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("Outcomes");
		  stage.show();
    }

    @FXML
    void listin(ActionEvent event) throws IOException {
    	Stage s = (Stage) lin.getScene().getWindow();
   	 	s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/listincome.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("listofincome");
		  stage.show();
    }
    @FXML
    void listout(ActionEvent event) throws IOException {
    	Stage s = (Stage) lout.getScene().getWindow();
   	 	s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/listoutcome.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("listoutcome");
		  stage.show();
    }
    
    @FXML
    void listblock(ActionEvent event) throws IOException {
    	Stage s = (Stage) lblock.getScene().getWindow();
   	 	s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/listblocks.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("listofblocks");
		  stage.show();
    }

    @FXML
    void report(ActionEvent event) throws IOException {
    	Stage s = (Stage) report.getScene().getWindow();
   	 	s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/report.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("Report");
		  stage.show();
    }
    
    @FXML
    void listpaid(ActionEvent event) throws IOException {
    	Stage s = (Stage) listpaid.getScene().getWindow();
   	 	s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/checkpaid.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("List of Paid People");
		  stage.show();
    }
    @FXML
    void initialize() throws SQLException {
       Models.Homemodel h=new Models.Homemodel();
       int s=h.getMoney();
      // money.setText(String.valueOf(s));
       int i=h.check();
       
       if(i==1)
       {
    	   cat.setVisible(true);
       }
       System.out.println(h.checkblock());
       if(h.checkblock())
       {
    	
    	  block.setDisable(true);
       }
       
    }
}
