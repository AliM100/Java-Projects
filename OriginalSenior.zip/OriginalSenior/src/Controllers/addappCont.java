package Controllers;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

import application.Database;
import application.temp;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class addappCont {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField nametxt;

    @FXML
    private TextField Teltxt;

    @FXML
    private Button h;

    @FXML
    private Button inc;

    @FXML
    private Button out;

    @FXML
    private Button lin;

    @FXML
    private Button lout;

    @FXML
    private Button logout;

    @FXML
    private Button sub;

    @FXML
    private TextField bname;

    @FXML
    private TextField email;

    @FXML
    private TextField username;

    @FXML
    private PasswordField pass;

    @FXML
    private CheckBox isadmin;

    @FXML
    private ComboBox<?> ccat;

    @FXML
    private ComboBox<?> ctype;

    @FXML
    private TextField rname;

    @FXML
    private TextField rtel;

    @FXML
    private TextField remail;

    @FXML
    private TextField partnum;


    Models.addappmodel in;
    
    Database d=new Database();
	ObservableList oblist = FXCollections.observableArrayList();
    @FXML
    void Home(ActionEvent event) throws IOException {
    	Stage s = (Stage) h.getScene().getWindow();
     	 s.close();
   	Parent parent=FXMLLoader.load(getClass().getResource("/Views/Home.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("Home");
		  stage.show();
    }

    @FXML
    void income(ActionEvent event) throws IOException {
    	Stage s = (Stage) inc.getScene().getWindow();
		s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/Income.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("Income");
		  stage.show();
    }

    @FXML
    void listin(ActionEvent event) throws IOException {
    	Stage s = (Stage) lin.getScene().getWindow();
      	 s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/listincome.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("listofincome");
		  stage.show();
    }

    @FXML
    void listout(ActionEvent event) throws IOException {
    	Stage s = (Stage) lout.getScene().getWindow();
     	 s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/listoutcome.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("listofoutcome");
		  stage.show();
    }

    @FXML
    void logout(ActionEvent event) throws IOException {
    	Stage s = (Stage) logout.getScene().getWindow();
   	 s.close();
   	Parent parent=FXMLLoader.load(getClass().getResource("/Views/login.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("Login");
		  stage.show();
    }

    @FXML
    void outcome(ActionEvent event) throws IOException {
    	Stage s = (Stage) out.getScene().getWindow();
      	 s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/Outcome.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("Outcome");
		  stage.show();
    }

    @FXML
    void submit(ActionEvent event)  throws SQLException  {
    	
    	
    	if(bname.getText().isEmpty() ||nametxt.getText().isEmpty() || Teltxt.getText().isEmpty()|| email.getText().isEmpty() || username.getText().isEmpty() || pass.getText().isEmpty()  || ccat.getValue()==null || ctype.getValue()==null || partnum.getText().isEmpty())
    	{
 		
   		 Alert a = new Alert(AlertType.NONE);
  		  a.setAlertType(AlertType.ERROR);
  		  a.setContentText("Empty Fields");
          a.show();
    	}
    	else
    	{	
    		temp t =new temp() ;
    		boolean ad=isadmin.isSelected();
    	System.out.println("in list "+t.getflag());
    			if(t.getflag()==0)
    			{
    				in=new Models.addappmodel(partnum.getText(),bname.getText(),nametxt.getText(), Teltxt.getText(), email.getText(),ad,ccat.getValue().toString(),ctype.getValue().toString(),rtel.getText(),rname.getText(),remail.getText(),0);
    				in.insert(username.getText(),pass.getText());
    			}
    			else if(t.getflag()==1)
    			{
    				
    				 ObservableList <Models.addappmodel> O= t.getO();
    				 Models.addappmodel tt=O.get(0);
    				 in=new Models.addappmodel(partnum.getText(),bname.getText(),nametxt.getText(), Teltxt.getText(), email.getText(),ad,ccat.getValue().toString(),ctype.getValue().toString(),rtel.getText(),rname.getText(),remail.getText(),0);
    				 in.update(tt.getName(),tt.getPartnum(),username.getText(),pass.getText());
    				 t.setflag(0);
    			}
    			
    	}
    }

    @FXML
    void initialize() throws SQLException {
    	
    	oblist=d.getcat(1, "A", "O","");
    	ccat.setItems(oblist);
    	}
    @FXML
    void isselected() throws SQLException {
    	
    		int code=d.getcode(ccat.getSelectionModel().getSelectedItem().toString());
    		 String T=d.getT(code);
    		 oblist=d.getcat(2,T,"","");
        	ctype.setItems(oblist);
    	
    }

    @FXML
    void isselected1(ActionEvent event) {
//    	String sel=ctype.getSelectionModel().getSelectedItem().toString();
//    	if(!sel.equals("Ownership Apartment"))
//    	{
//    		System.out.println("entered");
//    		rname.setVisible(true);
//    		rtel.setVisible(false);
//    		remail.setVisible(false);
//    	}
    }
}
