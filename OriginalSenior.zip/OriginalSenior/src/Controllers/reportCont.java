package Controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import org.omg.IOP.MultipleComponentProfileHelper;

import Models.Outcomemodel;
import application.Database;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.MultipleSelectionModel;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class reportCont {

	@FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button h;

    @FXML
    private Button in;

    @FXML
    private Button outc;

    @FXML
    private Button lout;
    @FXML
    private Button lin;

    @FXML
    private TableView<application.report> Itab;

    @FXML
    private TableColumn<application.report, String> Colname;

    @FXML
    private TableColumn<application.report, String> Colamount;

    @FXML
    private TableColumn<application.report, String> Colfrom;

    @FXML
    private TableColumn<application.report, String> Colto;

    @FXML
    private TableColumn<application.report, String> Colsub;

    @FXML
    private TableColumn<application.report, String> Colpartnum;

    @FXML
    private TableColumn<application.report, String> Colcat;
    @FXML
    private TableColumn<application.report, String> Coldate;
    @FXML
    private Button logout;

    @FXML
    private Button loaddata;

    @FXML
    private DatePicker D1;

    @FXML
    private DatePicker D2;
    

    @FXML
    private Button export;
    
    @FXML
    private ComboBox<?> cat;
    @FXML
    private Label money;
    @FXML
    private ComboBox<?> subcat;
    @FXML
    private ListView<String> listsub;
    
    Database d=new Database();
    Models.reportmodel lm=new Models.reportmodel();
    ObservableList oblist = FXCollections.observableArrayList();
    ObservableList oblist1 = FXCollections.observableArrayList();
    ObservableList a = FXCollections.observableArrayList();
    String sel;
    @FXML
    void Load(ActionEvent event) throws SQLException {
    	 String dd1=D1.getValue().toString();
    	 String dd2=D2.getValue().toString();
     	if( dd1.isEmpty() || dd2.isEmpty())
     	{
    		 Alert a = new Alert(AlertType.NONE);
   		  a.setAlertType(AlertType.ERROR);
   		  a.setContentText("Empty Fields");
               a.show();
     	}
     	else
     	{
     		//Colname.setCellValueFactory(new PropertyValueFactory<>("name"));
     		Colamount.setCellValueFactory(new PropertyValueFactory<>("total"));
     		Colsub.setCellValueFactory(new PropertyValueFactory<>("subcat"));
     //		Coldate.setCellValueFactory(new PropertyValueFactory<>("date"));
     		Colcat.setCellValueFactory(new PropertyValueFactory<>("cat"));
     
    		Itab.setItems(lm.list(cat.getSelectionModel().getSelectedItem().toString(),a,dd1, dd2));
    		
     	}
    }
    
    @FXML
    void Home(ActionEvent event) throws IOException {
    	Stage s = (Stage) h.getScene().getWindow();
      	 s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/Home.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("Home");
		  stage.show();
    }
    
    @FXML
    void income(ActionEvent event) throws IOException {
    	Stage s = (Stage) in.getScene().getWindow();
     	 s.close();
   	Parent parent=FXMLLoader.load(getClass().getResource("/Views/Income.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("Income");
		  stage.show();
    }

    @FXML
    void listin(ActionEvent event) throws IOException {
    	Stage s = (Stage) lin.getScene().getWindow();
      	 s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/listincome.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("listofincome");
		  stage.show();
    }

    @FXML
    void listout(ActionEvent event) throws IOException {
    	Stage s = (Stage) lout.getScene().getWindow();
     	 s.close();
    	Parent parent=FXMLLoader.load(getClass().getResource("/Views/listoutcome.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("listofoutcome");
		  stage.show();
    }

    @FXML
    void logout(ActionEvent event) throws IOException {
    	Stage s = (Stage) logout.getScene().getWindow();
   	 s.close();
   	Parent parent=FXMLLoader.load(getClass().getResource("/Views/login.fxml"));
		  Stage stage=new Stage();
		  stage.setScene(new Scene(parent));
		  stage.setTitle("Login");
		  stage.show();
    }

    @FXML
    void outcome(ActionEvent event) throws IOException {
    	Stage s = (Stage) outc.getScene().getWindow();
      	 s.close();
      	Parent parent=FXMLLoader.load(getClass().getResource("/Views/Outcome.fxml"));
   		  Stage stage=new Stage();
   		  stage.setScene(new Scene(parent));
   		  stage.setTitle("Outcome");
   		  stage.show();
    }

    @FXML
    void exportexcel(ActionEvent event) throws IOException {
    	lm.export();
    }
    @FXML
    void isselected(ActionEvent event) throws SQLException {
    	String s=cat.getSelectionModel().getSelectedItem().toString();
     int code=d.getcode(cat.getSelectionModel().getSelectedItem().toString());
		 String T=d.getT(code);
		 if(s.equals("All"))
		 {
			 oblist1=d.getcat(3,"","Income","Outcome");
		 }
		 else{
			 oblist1=d.getcat(3,T,"All","");
		 }
		 subcat.setItems(oblist1);
    }

    @FXML
    void isselected1(ActionEvent event) {
    	String s=subcat.getSelectionModel().getSelectedItem().toString();
    	a.add(s);
    	listsub.getItems().add(s);
    }

    @FXML
    void initialize() throws SQLException {
    	int s=d.getTotalmoney(d.getbname());
    	money.setText(String.valueOf(s));
    	oblist=d.getcat(1, "Income", "Outcome","All");
     	cat.setItems(oblist);
     
    }
}
