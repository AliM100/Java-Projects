package Controllers;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javax.swing.plaf.basic.BasicOptionPaneUI.ButtonActionListener;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class logincont {
	
Models.loginmodel lo=new Models.loginmodel();
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
   @FXML 
    private TextField usr;
   @FXML 
   private TextField pass;
   @FXML 
   private Button login;
   @FXML 
   private Button register;
   @FXML
   private Label label1;
   @FXML
   void onbtnlog(ActionEvent event) throws Exception, Exception {
	  
	   
    if(usr.getText().isEmpty() || pass.getText().isEmpty())
    	
    {
    	
    	label1.setText("Empty fields");	
    	return;
    }
    else {
    	 
    	String username,password;
    	username=usr.getText();
    	password=pass.getText();
    	if(lo.comparedata(username, password))
    	{
    		Stage s = (Stage) login.getScene().getWindow();
    		s.close();
    		Parent parent=FXMLLoader.load(getClass().getResource("/Views/Home.fxml"));
    		  Stage stage=new Stage();
    		  stage.setScene(new Scene(parent));
    		  stage.setTitle("Home");
    		  stage.show();
    	}else label1.setText("Login Failed !");
    }
   }
   

   @FXML
   void regis(ActionEvent event) throws Exception {
	  Parent parent=FXMLLoader.load(getClass().getResource("register.fxml"));
        Scene scene=new Scene(parent);
        Stage stage=new Stage();
        stage.setScene(scene);
        stage.show();
   }
   
   
    @FXML
    void initialize() {
    	
    }
}
