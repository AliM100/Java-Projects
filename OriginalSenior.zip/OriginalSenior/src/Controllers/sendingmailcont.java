package Controllers;
import java.net.URL;
import java.sql.SQLException;
import java.util.Observable;
import java.util.ResourceBundle;

import Models.addappmodel;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class sendingmailcont {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button sendbtn;

    @FXML
    private TextArea text;
    @FXML
    private Button cancel;
    ObservableList <Models.addappmodel> O;
    Models.sendingmailmodel smm;
    @FXML
    void canceling(ActionEvent event) {
    	Stage s = (Stage) cancel.getScene().getWindow();
     	 s.close();
    }

    @FXML
    void sending(ActionEvent event) throws SQLException {
    	
    	
    		smm=new Models.sendingmailmodel();
    		smm.mail(text.getText().toString());
    }

    @FXML
    void initialize() {
       
    
    }
  
	
  
}
