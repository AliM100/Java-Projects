 package application;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.sun.glass.ui.Application;

import Models.Outcomemodel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Alert.AlertType;

public class Database {
	Statement st1;
	Statement st2;
	Statement st3;
	static String db="jdbc:sqlserver://DESKTOP-40L1C9K;databaseName=senior";
	static String user="sa";
	static String pass="123";
	private static Connection con=null;
     String q;
     final String secretkey="this is a senior project";
    AES aes=new AES();
     public static Connection getDBConnection()
     {
    	 try{
    		 
    		 if(con==null)
    		 {
    			 DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
    			 con=DriverManager.getConnection(db,user,pass);
    		 }
    	 }catch(Exception e)
    	 {
    		 e.printStackTrace();
    	 }
    	 return con;
     }
     
	public ResultSet Da(String usern,String pass1 ) throws SQLException{
		  ResultSet res = null;
		 
		try {   
            con=getDBConnection();
        	q="select AOID,AOUSERNAME,AOPASSWORD from APARTMENTOWNER where AOUSERNAME=(?) and AOPASSWORD=(?)";
    		PreparedStatement p = con.prepareStatement(q);
    		String u=aes.encrypt(usern, secretkey);
    		String pa=aes.encrypt(pass1, secretkey);
    		p.setString(1,u);
    		p.setString(2,pa);
            res=p.executeQuery();
            
		}
		catch(SQLException ex) {
			System.out.println(ex);
			System.out.println(ex.getMessage());
			System.out.println("Connection Error");
		}
		 return res; 
	}
      
       public void insert(String a,String email,String username,String password) throws SQLException {
    	   String u=aes.encrypt(username, secretkey);
    	   String pa=aes.encrypt(password, secretkey);
    	   String q="INSERT INTO usrlogin values('"+a+"','"+email+"','"+u+"','"+pa+"')";
    	  try {
    		  
    		  con=getDBConnection();
    		 st2=con.createStatement();
    		 st2.executeQuery(q);
    	  }catch(SQLException ex) {
    		  System.out.println(ex);
    	  }
    	
       }
       
       public int addtototal(String bname,int amount) throws SQLException
       {
    	   String q0="Select *from Block where Blockname='"+bname+"'";
    	   String q="Update Block set TotalMoney=TotalMoney+'"+amount+"' where Blockname='"+bname+"'";
    	   try {
			con=getDBConnection();
			st3=con.createStatement();
			ResultSet res;
			res=st3.executeQuery(q0);
			if(res.next())
			{
				st3.executeQuery(q);
			}else {
				
				return 0;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	   
    	   return 1;
       }
     
       public boolean insertIncome(int Pid,String partnum,String name,String amount,String from,int cat,int type,String date) throws SQLException {
    	  
    	   String q="Insert into Incomes values('"+Pid+"','"+partnum+"','"+name+"','"+amount+"','"+from+"','"+cat+"','"+type+"','"+date+"')";
       	 
    	  try {
    		 con=getDBConnection();
    		 st2=con.createStatement();
   
    		 st2.executeQuery(q);
    		
    	  }catch(SQLException ex) {
    		  System.out.println(ex);
    		  return false;
    	  }
    	 return true;
       }
       public boolean insertBlock(String brn,String name,int money) throws SQLException {
    		String p1="Select BLOCKNAME from BLOCK where BREALESTATENUMBER='"+brn+"' ";
    	   String q="Insert into Block  values('"+brn+"','"+name+"','"+money+"')";
    	  try {
    		  ResultSet res;
    		 con=getDBConnection();
    		 st2=con.createStatement();
    		 st3=con.createStatement();
    		 res=st2.executeQuery(p1);
    		 if(res.next())
    		 {
    			 Alert a = new Alert(AlertType.NONE);
		  		  a.setAlertType(AlertType.ERROR);
		  		  a.setContentText("Block Exist");
		           a.show();
    			 
    			 return false;
    		 }else
    		 {
    			 st3.executeQuery(q);
    			return true;
    		 }
    	  }catch(SQLException ex) {
    		  System.out.println(ex);
    	  }
    	return true;
       }
       public void subtotal(String bname,int amount) throws SQLException
       {
    	   String q2=" Update Block set TotalMoney=TotalMoney-'"+amount+"' where Blockname='"+bname+"'";
    	   try {
     		  
      		 con=getDBConnection();
      		 st2=con.createStatement();
      		 st2.executeQuery(q2);
      	  }catch(SQLException ex) {
      		  System.out.println(ex);
      	  }
    	   
       }
       public boolean insertOutcome(int Pid,String partnum,String name,String amount,String to,int cat,int type,String date,String path) throws SQLException {
    	  
   	   String q="Insert into Outcomes  values('"+Pid+"','"+partnum+"','"+name+"','"+amount+"','"+to+"','"+cat+"','"+type+"','"+date+"','"+path+"')";
    		    	   		
   	 try { 
		 con=getDBConnection();
		 st2=con.createStatement();
		 st2.executeQuery(q);
	  }catch(SQLException ex) {
		  System.out.println(ex);
	  }
   	 return true;
     }
       
       public boolean  insertapp(String partn,int Bid,String blockrealnum,String name,String tel,String email,int isadmin,int cat,int type,String username,String password,String rname,String rtel,String remail,int inam) throws SQLException {
    	   String u=aes.encrypt(username, secretkey);
    	   String pa=aes.encrypt(password, secretkey);
       	   String q="Insert into APARTMENTOWNER  values('"+partn+"','"+Bid+"','"+blockrealnum+"','"+name+"','"+tel+"','"+email+"','"+isadmin+"','"+cat+"','"+type+"','"+u+"','"+pa+"','"+rname+"','"+rtel+"','"+remail+"','"+inam+"')";
      	String p1="Select AONAME from APARTMENTOWNER where AOPARTNUM='"+partn+"' or AONAME='"+name+"' "; 
//		String p2="Update APARTMENTOWNER set AOPARTNUM='"+partn+"',BLOCKID='"+Bid+"',BREALESTATENUMBER='"+blockrealnum+"',AONAME='"+name+"',AOTEL='"+tel+"',AOEMAIL='"+email+"',AOISADMIN='"+isadmin+"',AOCAT='"+cat+"',AOTYPE='"+type+"',AOUSERNAME='"+username+"',AOPASSWORD='"+password+"',AORNAME='"+rname+"',AORTEL='"+rtel+"',AOREMAIL='"+remail+"',AOINCOMEAMOUNT='"+inam+"' where AONAME='"+name+"'";
	  try {
		  ResultSet res;
		 con=getDBConnection();
		 st2=con.createStatement();
		 st3=con.createStatement();
		 res=st2.executeQuery(p1);
		 //check if exist
		 if(res.next())
		 {//if exist then update
////			 st3.executeQuery(p2);
		 Alert a = new Alert(AlertType.NONE);
 		  a.setAlertType(AlertType.ERROR);
 		  a.setContentText("Owner Exist");
          a.show();
			 return false;
		 }
//		 //doesn't exist -> insert
		 else 
		 {
			 st3.executeQuery(q);
			 return true;
		 }
	  }catch(SQLException ex) {
		  System.out.println(ex);
		 
	  }
	  return true;
	 }
      
       public boolean updateapp(String oldname,String oldpartnum,String partn,int Bid,String blockrealnum,String name,String tel,String email,int isadmin,int cat,int type,String username,String password,String rname,String rtel,String remail,int inam) throws SQLException {
    	   String u=aes.encrypt(username, secretkey);
    	   String pa=aes.encrypt(password, secretkey);
		String p="Update APARTMENTOWNER set AOPARTNUM='"+partn+"',BLOCKID='"+Bid+"',BREALESTATENUMBER='"+blockrealnum+"',AONAME='"+name+"',AOTEL='"+tel+"',AOEMAIL='"+email+"',AOISADMIN='"+isadmin+"',AOCAT='"+cat+"',AOTYPE='"+type+"',AOUSERNAME='"+u+"',AOPASSWORD='"+pa+"',AORNAME='"+rname+"',AORTEL='"+rtel+"',AOREMAIL='"+remail+"',AOINCOMEAMOUNT='"+inam+"' where AONAME='"+oldname+"' and AOPARTNUM='"+oldpartnum+"'";
	  try {
		  ResultSet res;
		 con=getDBConnection();
		 st2=con.createStatement();
		 res=st2.executeQuery(p);
	
			 st3.executeQuery(p);
			
	  }catch(SQLException ex) {
		  System.out.println(ex);
	  }
	  return true;
	 }
       public boolean updateOutcome(String oldname,int Pid,String partnum,String name,String amount,String to,int cat,int type,String date,String path) throws SQLException {
     	  
       	   String q="Update Outcomes  set AOID='"+Pid+"',AOPARTNUM='"+partnum+"',OUNAME='"+name+"',OUAMOUNT='"+amount+"',OUTO='"+to+"',OCAT='"+cat+"',OUTYPE='"+type+"',OUD='"+date+"',ODOC='"+path+"' where OUNAME='"+oldname+"'";
        		    	   		
       	 try { 
    		 con=getDBConnection();
    		 st2=con.createStatement();
    		 st2.executeQuery(q);
    	  }catch(SQLException ex) {
    		  System.out.println(ex);
    	  }
       	 return true;
         }
       public boolean updateIncome(String oldname,int Pid,String partnum,String name,String amount,String from,int cat,int type,String date) throws SQLException {
     	  
    	   String q="Update Incomes set AOID='"+Pid+"',AOPARTNUM='"+partnum+"',INAME='"+name+"',IAMOUNT='"+amount+"',IFROM='"+from+"',ICAT='"+cat+"',ITYPE='"+type+"',IDA='"+date+"' where INAME='"+oldname+"'";
       	 
    	  try {
    		 con=getDBConnection();
    		 st2=con.createStatement();
   
    		 st2.executeQuery(q);
    		
    	  }catch(SQLException ex) {
    		  System.out.println(ex);
    	  }
    	 return true;
       }
       public int getTotalmoney(String B) throws SQLException {

    	   int id=0;
       	   String q="Select TOTALMONEY from Block where BLOCKNAME='"+B+"'";
        		    	   		
        	  try {
        		  ResultSet res;
        		 con=getDBConnection();
        		 st2=con.createStatement();
        		 res=st2.executeQuery(q);
        		 if(res.next())
        		 {
        			 id=res.getInt("TOTALMONEY");
        			 return id;
        		 }
        		 else {
        			
        			 return -1;
        		 }
        	  }catch(SQLException ex) {
        		  System.out.println(ex);
        	  }
        	  
        	 return -1;
           }
       public int getid() throws SQLException {

    	   int id=0;
       	   String q="Select BLOCKID from Block ";
        		    	   		
        	  try {
        		  ResultSet res;
        		 con=getDBConnection();
        		 st2=con.createStatement();
        		 res=st2.executeQuery(q);
        		 if(res.next())
        		 {
        			 id=res.getInt("BLOCKID");
        			 return id;
        		 }
        		 else {
        			
        			 return -1;
        		 }
        	  }catch(SQLException ex) {
        		  System.out.println(ex);
        	  }
        	  
        	 return -1;
           }
       public int getAoid(String name) throws SQLException {

    	   int id=0;
       	   String q="Select AOID from APARTMENTOWNER where AONAME='"+name+"' ";
        		    	   		
        	  try {
        		  ResultSet res;
        		 con=getDBConnection();
        		 st2=con.createStatement();
        		 res=st2.executeQuery(q);
        		 if(res.next())
        		 {
        			 id=res.getInt("AOID");
        			
        			 return id;
        		 }
        		 else {
        			
        			 return -1;
        		 }
        	  }catch(SQLException ex) {
        		  System.out.println(ex);
        	  }
        	  
        	 return -1;
           }
       public String getpart(String s) throws SQLException {

    	   String id;
       	   String q="Select AOPARTNUM from APARTMENTOWNER where AONAME='"+s+"' ";
        		    	   		
        	  try {
        		  ResultSet res;
        		 con=getDBConnection();
        		 st2=con.createStatement();
        		 res=st2.executeQuery(q);
        		 if(res.next())
        		 {
        			 id=res.getString("AOPARTNUM");
        			 //System.out.println(id);
        			 
        			 return id;
        		 }
        		
        	  }catch(SQLException ex) {
        		  System.out.println(ex);
        	  }
        	  
        	 return null;
           }
       public int checkpart(String s) throws SQLException {

    	  
       	   String q="Select AOPARTNUM from APARTMENTOWNER where AOPARTNUM='"+s+"' ";
        		    	   		
        	  try {
        		  ResultSet res;
        		 con=getDBConnection();
        		 st2=con.createStatement();
        		 res=st2.executeQuery(q);
        		 if(res.next())
        		 {
        			 
        			 return 1;
        		 }
        		
        	  }catch(SQLException ex) {
        		  System.out.println(ex);
        	  }
        	  
        	 return 0;
           }
       public String getmail(String B) throws SQLException {
    	   String q="Select AOEMAIL from APARTMENTOWNER  where AONAME='"+B+"'";
    	 
    	   String email = null;	   		
       	 	try {
        		  ResultSet res;
        		 con=getDBConnection();
        		 st2=con.createStatement();
        		
        		 res=st2.executeQuery(q);
        		 if(res.next())
        		 {
        			 email=res.getString("AOEMAIL");
        			 
        			 return email;
        		 }
        	  }catch(SQLException ex) {
        		  System.out.println(ex);
        	  }
       	 	
        	 return email;
           }
	public ObservableList getlistOutcomes(int cc,String D1,String D2) throws SQLException
       {
    	   String q="Select * from Outcomes where OCAT='"+cc+"' and OUD>='"+D1+"' and OUD<='"+D2+"'";
    	   String q1="Select * from Outcomes where OUD>='"+D1+"' and OUD<='"+D2+"'";
    	   ObservableList<Models.Outcomemodel> oblist = FXCollections.observableArrayList();
    	   Models.Outcomemodel o;
    	   try { 
    		   
    		   ResultSet res;
      		 con=getDBConnection();
      		 st2=con.createStatement();
      		if(getDesc(cc).equals("All"))
       		{
       			res=st2.executeQuery(q1);
       		}
       		else res=st2.executeQuery(q);
      		 while(res.next())
      		 {
      			int  c=res.getInt("OCAT");
      			int  t=res.getInt("OUTYPE");
      			String partnum=res.getString("AOPARTNUM");
      			 String amount=res.getString("OUAMOUNT");
      			 String to=res.getString("OUTO");
      			String name=res.getString("OUNAME");
      			 String date=res.getString("OUD");
      			 String file=res.getString("ODOC");
      			 String cat=getDesc(c);
      			 String type=getDesc(t);
      			 o=new Models.Outcomemodel( partnum,name,amount, to,cat, type, date,file);
      			 oblist.add(o);
      		 }
      	  }catch(SQLException ex) {
      		  System.out.println(ex);
      	  }
    	   
		return oblist;
    	   
       }
	public ObservableList getlistIncome(int cc,String D1,String D2) throws SQLException
    {
 	   String q="Select * from incomes where ICAT='"+cc+"' and IDA>='"+D1+"' and IDA<='"+D2+"'";
 	  String q1="Select * from incomes where  IDA>='"+D1+"' and IDA<='"+D2+"'";
 	   ObservableList<Models.Incomemodel> oblist = FXCollections.observableArrayList();
 	   Models.Incomemodel o;
 	   try { 
 		   
 		   ResultSet res;
   		 con=getDBConnection();
   		 st2=con.createStatement();
   		if(getDesc(cc).equals("All"))
   		{
   			res=st2.executeQuery(q1);
   		}
   		else res=st2.executeQuery(q);
   		 
   		 while(res.next())
   		 {
   			String partnum=res.getString("AOPARTNUM");
   			 String amount=res.getString("IAMOUNT");
   			 String from=res.getString("IFROM");
   			int c=res.getInt("ICAT");
   			 int t=res.getInt("ITYPE");
   			 String name=res.getString("INAME");
   			 String date=res.getString("IDA");
   			 String cat=getDesc(c);
   			 String type=getDesc(t);
   			 o=new Models.Incomemodel( partnum,name,amount, from,cat, type, date);
   			 oblist.add(o);
   		 }
   	  }catch(SQLException ex) {
   		  System.out.println(ex);
   	  }
 	  
		return oblist;
 	   
    }
	
	public ObservableList getlistapp() throws SQLException
    {
		String q="Select * from apartmentowner";
 	   ObservableList<Models.addappmodel> ob = FXCollections.observableArrayList();
 	   Models.addappmodel o;
 	   try { 
 		   
 		   ResultSet res;
   		 con=getDBConnection();
   		 st2=con.createStatement();
   		 res=st2.executeQuery(q);
   		 while(res.next())
   		 {
   			String partnum=res.getString("AOPARTNUM");
   			String ben=res.getString("BREALESTATENUMBER");
   			 String n=res.getString("AONAME");
   			 String t=res.getString("AOTEL");
   			 String em=res.getString("AOEMAIL");
   			 boolean isad=res.getBoolean("AOISADMIN");
   			int ca=res.getInt("AOCAT");
   			int ty=res.getInt("AOTYPE");
   			String rtel=res.getString("AORTEL");
   			String rname=res.getString("AORNAME");
   			String rem=res.getString("AOREMAIL");
   			String cat=getDesc(ca);
   			String type=getDesc(ty);
   			int inamount =res.getInt("AOINCOMEAMOUNT");
   			
   			
   			 o=new Models.addappmodel( partnum, ben, n, t,  em,  isad, cat, type, rtel, rname, rem,inamount);
   			 ob.add(o);
   		 }
   	  }catch(SQLException ex) {
   		  System.out.println(ex);
   	  }
 	   
		return ob;
 	   
    }
	public ObservableList getlistpay(String D1,String D2) throws SQLException
    {
		
		
		String q="Select * from apartmentowner";
		
 	   ObservableList<application.checkpaid> ob = FXCollections.observableArrayList();
 	  application.checkpaid o;
 	   try { 
 		   
 		   ResultSet res;ResultSet res1;
   		 con=getDBConnection();
   		 st2=con.createStatement();
   		st3=con.createStatement();
   		 res=st2.executeQuery(q);
   		 while(res.next())
   		 {
   			String partnum=res.getString("AOPARTNUM");
   			String ben=res.getString("BREALESTATENUMBER");
   			 String n=res.getString("AONAME");
   			 String t=res.getString("AOTEL");
   			 String em=res.getString("AOEMAIL");
   			 boolean isad=res.getBoolean("AOISADMIN");
   			int ca=res.getInt("AOCAT");
   			int ty=res.getInt("AOTYPE");
   			String rtel=res.getString("AORTEL");
   			String rname=res.getString("AORNAME");
   			String rem=res.getString("AOREMAIL");
   			String cat=getDesc(ca);
   			String type=getDesc(ty);
   			int inamount =res.getInt("AOINCOMEAMOUNT");
   			boolean paid;
   			String from=n;
   			
   			String q1="Select * from Incomes where IFROM='"+from+"'  and  IDA>='"+D1+"' and IDA<='"+D2+"' ";
   			res1=st3.executeQuery(q1);
   			if(res1.next())
   			{
   				paid=true;
   			}else paid=false;
   			
   			 o=new application.checkpaid( partnum, ben, n, t,  em,  isad, cat, type, rtel, rname, rem,inamount,paid);
   			 ob.add(o);
   		 }
   	  }catch(SQLException ex) {
   		  System.out.println(ex);
   	  }
 	   
		return ob;
 	   
    }
	 public ArrayList<String> getlistcat(String T,String D1,String D2)
	   {
		   String q="Select DISTINCT ICAT from Incomes where   IDA>='"+D1+"' and IDA<='"+D2+"' ";
		   String q1="Select DISTINCT OCAT from Outcomes where OUD>='"+D1+"' and OUD<='"+D2+"' ";
		  ArrayList <String> a=new ArrayList<String>();
		  int i=0;
		   try { 
			   ResultSet res;
			System.out.println(T.toString());
			   if(T.toString().equals("Income"))
			   {
				   res=st2.executeQuery(q);
			   }else {
				   res=st2.executeQuery(q1);
			   }
			   
		   		 while(res.next())
		   		 {
		   			i=res.getInt(1);
		   		 String catt=getDesc(i);
		   		 a.add(catt);
		   		 }
	  	  }catch(SQLException ex) {
	  		  System.out.println(ex);
	  	  }
		   
			return a;
		   
	   }
	public  application.report getreportincome(String t,int cat,String D1,String D2) throws SQLException
    {
		String q="Select SUM(IAMOUNT) from Incomes   where ICAT='"+cat+"' and  IDA>='"+D1+"' and IDA<='"+D2+"' ";
		String q1="Select SUM(OUAMOUNT) from Outcomes   where OCAT='"+cat+"' and  OUD>='"+D1+"' and OUD<='"+D2+"' ";
		String p="Select SUM(IAMOUNT) from Incomes  where  IDA>='"+D1+"' and IDA<='"+D2+"' ";
		String p1="Select SUM(OUAMOUNT) from Outcomes   where  OUD>='"+D1+"' and OUD<='"+D2+"' ";
		 application.report r = null;
 	  int i=0,i1=0;
 	   try { 
 		   
 		   ResultSet res;
 		  ResultSet res1;
   		 con=getDBConnection();
   		 st2=con.createStatement();
   		st3=con.createStatement();
   		if(getDesc(cat).equals("All"))
   		{
   			res=st2.executeQuery(p);
      		 if(res.next())
      		 {
      			i=res.getInt(1);
      			
      		 }
      			res1=st3.executeQuery(p1);
      			if(res1.next())
      			{
      				i1=res1.getInt(1);
      	   			
      			}
      			
     			 String catt=getDesc(cat);
     			 if(i==0)
     			 {
     				 r=new application.report( "", t,catt, i1);
     			 }else if(i1==0)
     				r=new application.report( "", t,catt, i);
     			 return r;
   		}else {
   		 res=st2.executeQuery(q);
   		 if(res.next())
   		 {
   			i=res.getInt(1);
   			
   		 }
   			res1=st3.executeQuery(q1);
   			if(res1.next())
   			{
   				i1=res1.getInt(1);
   	   			
   			}
   			
  			 String catt=getDesc(cat);
  			 if(i==0)
  			 {
  				 r=new application.report( "", t,catt, i1);
  			 }else if(i1==0)
  				r=new application.report( "", t,catt, i);
   		}
   		
  			 
   	  }catch(SQLException ex) {
   		  System.out.println(ex);
   	  }
 	   
		return r;
 	   
    }
	

	public int getcode(String s) throws SQLException
	{
		
		String q="Select * from coding where desc_='"+s+"'";
		int i = 0;
		try {
			
  		  ResultSet res;
  		 con=getDBConnection();
  		 st2=con.createStatement();
  		 res=st2.executeQuery(q);
  		if(res.next())
  		{
  			 i=res.getInt("CODE");
  	  		
  		}
  		else  System.out.println("NOT found");
  	  }catch(SQLException ex) {
  		  System.out.println(ex);
  	  }
		
		return i;
	}
	public String getDesc(int s) throws SQLException
	{
		
		String q="Select desc_ from coding where code='"+s+"'";
		String i = null;
		try {
			
  		  ResultSet res;
  		 con=getDBConnection();
  		 st2=con.createStatement();
  		 res=st2.executeQuery(q);
  		if(res.next())
  		{
  			 i=res.getString("desc_");
  	  		
  		}
  		else  System.out.println("NOT found");
  	  }catch(SQLException ex) {
  		  System.out.println(ex);
  	  }
		
		return i;
	}
	public int getmoney(int s) throws SQLException
	{
		
		String q="Select MONEY from coding where code='"+s+"'";
		int i = 0;
		try {
  		  ResultSet res;
  		 con=getDBConnection();
  		 st2=con.createStatement();
  		 res=st2.executeQuery(q);
  		if(res.next())
  		{
  			 i=res.getInt("MONEY");
  	  		
  		}
  		else  System.out.println("NOT found");
  	  }catch(SQLException ex) {
  		  System.out.println(ex);
  	  }
		
		return i;
	}
	public ObservableList getcat(int level,String T1,String T2,String T3) throws SQLException
	{
		//String q="Select * from coding where LEVEL='"+level+"' and T in ('"+T1+"','"+T2+"')";
		String q="Select * from coding where LEVEL='"+level+"' and T in ('"+T1+"','"+T2+"','"+T3+"')";
		 ObservableList oblist = FXCollections.observableArrayList();
		try {
	  		  ResultSet res;
	  		 con=getDBConnection();
	  		 st2=con.createStatement();
	  		 res=st2.executeQuery(q);
	  		while(res.next())
	  		{
	  			String s=res.getString("DESC_");
	  			oblist.add(s);
	  		}
	  	  }catch(SQLException ex) {
	  		  System.out.println(ex);
	  	  }
		
		return oblist;
	}
	
	public String getT(int code) throws SQLException
	{
		String q="Select T from coding where code='"+code+"'";
		String i = null;
		try {
  		  ResultSet res;
  		 con=getDBConnection();
  		 st2=con.createStatement();
  		 res=st2.executeQuery(q);
  		 if(res.next()) {
  			 i=res.getString("T");
  		 }
  		
  	  }catch(SQLException ex) {
  		  System.out.println(ex);
  	  }
		
		return i;
	}
	
	public String getbname() throws SQLException
	{
		String q="Select BLOCKNAME from BLOCK ";
		String i = null;
		try {
  		  ResultSet res;
  		 con=getDBConnection();
  		 st2=con.createStatement();
  		 res=st2.executeQuery(q);
  		 if(res.next()) {
  			 i=res.getString("BLOCKNAME");
  		 }
  		
  	  }catch(SQLException ex) {
  		  System.out.println(ex);
  	  }
		
		return i;
	}
	 public boolean insertcoding(int code,String desc,String level,String T,int Money) throws SQLException {

     	   String q="Insert into coding  values('"+code+"','"+desc+"','"+level+"','"+T+"','"+Money+"')";
     	String p1="Select code from coding where code='"+code+"'"; 
		//String p2="Update coding set code='"+code+"',DESC_='"+desc+"',LEVEL='"+level+"',T='"+T+"',MONEY='"+Money+"'";
	  try {
		  ResultSet res;
		 con=getDBConnection();
		 st2=con.createStatement();
		 st3=con.createStatement();
		 res=st2.executeQuery(p1);
		 //check if exist
		 if(res.next())
		 {//if exist then update
			// st3.executeQuery(p2);
			 Alert a = new Alert(AlertType.NONE);
	 		  a.setAlertType(AlertType.ERROR);
	 		  a.setContentText("Category Exist");
	          a.show();
			 return false;
		 }
		 //doesn't exist -> insert
		 else {
			 st3.executeQuery(q);
			 return true;
		 }
	  }catch(SQLException ex) {
		  System.out.println(ex);
	  }
	  return true;
	 }
	 
	 public int check(int id) throws SQLException
		{
			String q="Select AOISADMIN from APARTMENTOWNER where AOID='"+id+"' ";
			int i =0;
			try {
	  		  ResultSet res;
	  		 con=getDBConnection();
	  		 st2=con.createStatement();
	  		 res=st2.executeQuery(q);
	  		 if(res.next()) {
	  			 i=res.getInt("AOISADMIN");
	  		 }
	  		
	  	  }catch(SQLException ex) {
	  		  System.out.println(ex);
	  	  }
			
			return i;
		}
	
//	public ObservableList getlistblock()
//    {
// 	   String q="Select BLOCKNAME,TOTALMONEY from BLOCK";
// 	   ObservableList<Models.addblockmodel> oblist = FXCollections.observableArrayList();
// 	   Models.addblockmodel o;
// 	   try { 
// 		   
// 		   ResultSet res;
//   		 con=DriverManager.getConnection(db,user,pass);
//   		 st2=con.createStatement();
//   		 res=st2.executeQuery(q);
//   		 while(res.next())
//   		 {
//   			 String bname=res.getString("BLOCKNAME");
//   			 String money=res.getString("TOTALMONEY");
//   			 
//   			 o=new Models.addblockmodel(bname,money);
//   			 oblist.add(o);
//   		 }
//   	  }catch(SQLException ex) {
//   		  System.out.println(ex);
//   	  }
// 	   
//		return oblist;
// 	   
//    }
    }