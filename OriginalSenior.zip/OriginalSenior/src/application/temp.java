package application;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class temp {
	static ObservableList <Models.addappmodel> O= FXCollections.observableArrayList();
	static ObservableList <application.checkpaid> OP= FXCollections.observableArrayList();
	static ObservableList <Models.Outcomemodel> Outcome= FXCollections.observableArrayList();
	static ObservableList <Models.Incomemodel> Income= FXCollections.observableArrayList();
	static int flag=0;
	static int flagIncome=0;
	static int flagOutcome=0;
	public static final ObservableList<Models.addappmodel> getO() {
		return O;
	}
	public static final void setO(ObservableList<Models.addappmodel> o) {
		O = o;
	}
	
	
	//for outcome update
	public static final void setOutcome(ObservableList<Models.Outcomemodel> o) {
		Outcome = o;
	}
	public static final ObservableList<Models.Outcomemodel> getOutcome() {
		return Outcome;
	}
	
	public static void setflagOutcome(int f)
	{
		flagOutcome=f;
	}
	public static int  getflagOutcome()
	{
		System.out.println(flagOutcome);
	   return flagOutcome;
	}
	////////////////////////
	//for Income update
	public static final void setIncome(ObservableList<Models.Incomemodel> o) {
		Income = o;
	}
	public static final ObservableList<Models.Incomemodel> getIncome() {
		return Income;
	}
	public static void setflagIncome(int f)
	{
		flagIncome=f;
	}
	public static int  getflagIncome()
	{
		System.out.println(flagIncome);
	   return flagIncome;
	}
	////////////////////////
	public static final ObservableList<application.checkpaid> getOP() {
		return OP;
	}
	public static final void setOP(ObservableList<application.checkpaid> o) {
		OP = o;
	}
	public static void setflag(int f)
	{
		flag=f;
	}
	public static int  getflag()
	{
		System.out.println(flag);
	   return flag;
	}
}
