package application;

public class checkpaid {

	public  String name,tel,email,date,blockrealnum,rtel,rname,remail;
	 public boolean isadmin;
	 public String cat,type,partnum;
	 public int moneyneeded;
public boolean paid;

	
	public checkpaid(String partnum,String aadn,String n,String t, String em,boolean  isad,String cat,String type,String rtel,String rname,String rem,int ina,boolean paid){
		this.name=n;
		this.tel=t;
		this.email=em;
		this.cat=cat;
		this.type=type;
		this.rname=rname;
		this.rtel=rtel;
		this.remail=rem;
      this.isadmin=isad;
      this.blockrealnum=aadn;
      this.partnum=partnum;
		//this.date=da;
      this.moneyneeded=ina;
      this.paid=paid;
	}
	
	public String getName() {
		return name;
	}

	public String getTel() {
		return tel;
	}

	public String getEmail() {
		return email;
	}

	public String getDate() {
		return date;
	}

	public String getBlockrealnum() {
		return blockrealnum;
	}

	public String getRtel() {
		return rtel;
	}

	public String getRname() {
		return rname;
	}

	public String getRemail() {
		return remail;
	}

	public boolean isIsadmin() {
		return isadmin;
	}

	public String getCat() {
		return cat;
	}

	public String getType() {
		return type;
	}

	public String getPartnum() {
		return partnum;
	}

	public int getMoneyneeded() {
		return moneyneeded;
	}

	public boolean isPaid() {
		return paid;
	}
}
