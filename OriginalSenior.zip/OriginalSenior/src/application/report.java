package application;

public class report {

	public String name, cat, subcat;int total;
	public report(String name,String cat,String subcat,int total)
	{
		this.name=name;
		this.cat=cat;
		this.subcat=subcat;
		this.total=total;
	}
	public String getName() {
		return name;
	}
	public String getCat() {
		return cat;
	}
	public String getSubcat() {
		return subcat;
	}
	public int getTotal() {
		return total;
	}
	
}
