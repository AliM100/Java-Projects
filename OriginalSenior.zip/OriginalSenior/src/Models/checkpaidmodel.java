package Models;

import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import application.Database;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class checkpaidmodel {

	Database d=new Database();
	 
	public ObservableList<application.checkpaid> list = FXCollections.observableArrayList();
	
	
public ObservableList list(String D1,String D2) throws SQLException
{
	
	list=d.getlistpay(D1,D2);

	return list;
}

public void export() throws IOException
{
	XSSFWorkbook wb=new XSSFWorkbook();
	XSSFSheet sheet=wb.createSheet("List of Paid Owners");
	XSSFRow  header=sheet.createRow(0);
	header.createCell(0).setCellValue("Name");
	header.createCell(1).setCellValue("Telephone");
	header.createCell(2).setCellValue("Email");
	header.createCell(3).setCellValue("IsAdmin");
	header.createCell(4).setCellValue("Appartment part number");
	header.createCell(5).setCellValue("Block Number");
	header.createCell(6).setCellValue("Type");
	header.createCell(7).setCellValue("Renter Name");
	header.createCell(8).setCellValue("Renter Telephone");
	header.createCell(9).setCellValue("Renter Email");
	header.createCell(10).setCellValue("Money Needed");
	header.createCell(11).setCellValue("Paid");
	for(int i=0;i<list.size();i++)
	{
		XSSFRow row=sheet.createRow(i+1);
		row.createCell(0).setCellValue(list.get(i).getName());
		row.createCell(1).setCellValue(list.get(i).getTel());
		row.createCell(2).setCellValue(list.get(i).getEmail());
		row.createCell(3).setCellValue(list.get(i).isIsadmin());
		row.createCell(4).setCellValue(list.get(i).getPartnum());
		row.createCell(5).setCellValue(list.get(i).getBlockrealnum());
		row.createCell(6).setCellValue(list.get(i).getType());
		row.createCell(7).setCellValue(list.get(i).getRname());
		row.createCell(8).setCellValue(list.get(i).getRtel());
		row.createCell(9).setCellValue(list.get(i).getRemail());
		row.createCell(10).setCellValue(list.get(i).getMoneyneeded());
		row.createCell(11).setCellValue(list.get(i).isPaid());
	}
	FileOutputStream fileOut=new FileOutputStream("List of Paid Owners.xlsx");
	wb.write(fileOut);
	fileOut.close();
	Alert alert=new Alert(AlertType.INFORMATION);
	alert.setTitle("Information Dialog");
	alert.setHeaderText(null);
	alert.setContentText("List of Paid Owners Exported in Excel.");
	alert.showAndWait();
}
	
}
