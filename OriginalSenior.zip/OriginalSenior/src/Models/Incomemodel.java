package Models;

import java.sql.Date;
import java.sql.SQLException;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import application.Database;
import application.sendmail;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;


public class Incomemodel {

	Database d=new Database();
	String  amount, from;
	String date,cat,type,partnum,name;
	
	
	
	public Incomemodel(String pn,String name,String a,String f,String cc,String t,String d2) throws SQLException {
		// TODO Auto-generated constructor stub
	
		this.cat=cc;
		this.amount=a;
		this.from=f;
		this.type=t;
		this.date=d2;
		this.name=name;
		if(d.getpart(f)!=null)
		{
			this.partnum=d.getpart(f).toString();
		}
		
		
		
	}
	


	public void insert()
	{
		try {
			 int id;
			 if(d.getAoid(from)!=0)
			 {
				 id=d.getAoid(from);
			 }else id=' ';
			int catt=d.getcode(cat);
			int ty=d.getcode(type);
			String bname=d.getbname();
			if(d.insertIncome(id,partnum,name,amount,from,catt,ty,date))
			{
				Alert a = new Alert(AlertType.NONE);
		  		  a.setAlertType(AlertType.INFORMATION);
		  		  a.setContentText("Income Added!");
		           a.show();
			}
			d.addtototal(bname, Integer.parseInt(amount));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void update(String oldname,String oldamount)
	{
		try {
			 int id;
			 if(d.getAoid(from)!=0)
			 {
				 id=d.getAoid(from);
			 }else id=0;
			int catt=d.getcode(cat);
			int ty=d.getcode(type);
			String bname=d.getbname();
			if(d.updateIncome(oldname,id,partnum,name,amount,from,catt,ty,date))
			{
				Alert a = new Alert(AlertType.NONE);
		  		  a.setAlertType(AlertType.INFORMATION);
		  		  a.setContentText("Income Updated!");
		           a.show();
			}
			d.subtotal(bname, Integer.parseInt(oldamount));
			d.addtototal(bname, Integer.parseInt(amount));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void mail(String text) throws SQLException
	{
		String email;
		if(d.getmail(from)!=null)
		{
			email=d.getmail(from);
			sendmail sm=new sendmail();
			sm.mailing(email, text);
		}
		
	}
	public Database getD() {
		return d;
	}

	public String getPartnum() {
		return partnum;
	}

	public String getCat() {
		return cat;
	}

	public String getAmount() {
		return amount;
	}
	public String getFrom() {
		return from;
	}
	public String getType() {
		return type;
	}
	public String getDate() {
		return date;
	}
	public String getName() {
		return name;
	}
	
	
}
