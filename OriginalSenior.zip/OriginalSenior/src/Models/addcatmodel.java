package Models;

import java.sql.SQLException;

import application.Database;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class addcatmodel {


	 

	Database d=new Database();
	
	
	String desc,totalmoney,code,level,type;
	 
	 public addcatmodel(String code,String desc,String level,String type,String Totalmoney)
	 {
		 this.code=code;
		 this.desc=desc;
		 this.level=level;
		 this.type=type;
		 this.totalmoney=Totalmoney;
	 }
	 public void insert() throws SQLException
		{
			
			if(d.insertcoding(Integer.parseInt(code),desc,level,type,Integer.parseInt(totalmoney))==true)
			{
				Alert a = new Alert(AlertType.NONE);
		  		  a.setAlertType(AlertType.INFORMATION);
		  		  a.setContentText("Category Added!");
		           a.show();
			}
			
		} 
	 
	

	 public String getDesc() {
		return desc;
	}
	public String getCode() {
		return code;
	}
	public String getLevel() {
		return level;
	}
	public String getType() {
		return type;
	}
	public void setTotalmoney(String totalmoney) {
		this.totalmoney = totalmoney;
	}
	

	
}
