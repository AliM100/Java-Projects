package Models;

import java.sql.SQLException;

import application.Database;

public class Homemodel {
	Database d=new Database();
	public int getMoney() throws SQLException
	{
		
		int s=d.getTotalmoney(d.getbname());
		return s;
	}
	public int check() throws SQLException
	{
		loginmodel l=new loginmodel();
		int i=l.getid();
		int c=d.check(i);
		if(c==1)
		{
			return 1;
		}
		else return 0;
	}
	public boolean checkblock() throws SQLException
	{
		String  r=d.getbname();
		if(r.isEmpty())
		{
			return false;
		}
		return true;
	}
}
