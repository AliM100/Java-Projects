package Models;        

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import application.Database;

public class loginmodel {
	ResultSet res;
	//ResultSetMetaData rsmd;
	String username,password;
	
	public static int id;
	
	public static int getid()
	{
		return id;
	}
	public boolean comparedata(String usern,String pass) throws SQLException {
		String q;
		application.Database db = new application.Database();
		
			res=db.Da(usern, pass);
		
			try {
			if(res.next())
			{
				id=res.getInt("AOID");
				System.out.println(id);
				return true;
			}
				
			return false;
			}catch(SQLException ex) {
				System.out.println(ex);
				System.out.println(ex.getMessage());
				return false;
			}
			
		
	
	}
}
