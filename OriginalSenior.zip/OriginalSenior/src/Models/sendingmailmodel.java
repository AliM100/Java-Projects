package Models;

import java.sql.SQLException;

import application.Database;
import application.sendmail;
import application.temp;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class sendingmailmodel {

	
	//Database d=new Database();
	ObservableList <Models.addappmodel> ob=FXCollections.observableArrayList();
	ObservableList <application.checkpaid> obp=FXCollections.observableArrayList();
	temp t;
	public void mail(String text) throws SQLException
	{
		sendmail sm=new sendmail();
		ob=t.getO();
		obp=t.getOP();
		if(ob.isEmpty())
		{
			
			
			for(int i=0;i<obp.size();i++)
			{
				
				//String email=d.getmail(ob.get(i).getName().toString());
				String email=obp.get(i).getEmail().toString();
				if(obp.get(i).getRemail()!=null)
				{
					String email1=obp.get(i).getRemail().toString();
					sm.mailing(email1, text);
				}
				
				sm.mailing(email, text);
			}
		}else {
		
			for(int i=0;i<ob.size();i++)
			{
				
				//String email=d.getmail(ob.get(i).getName().toString());
				String email=ob.get(i).getEmail().toString();
				if(ob.get(i).getRemail()!=null)
				{
					String email1=ob.get(i).getRemail().toString();
					sm.mailing(email1, text);
				}
				
				sm.mailing(email, text);
			}
		}
		
		
	}
}
