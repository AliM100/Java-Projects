package Models;

import java.sql.SQLException;

import application.Database;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class addappmodel {

	public  String name,tel,email,date,blockrealnum,rtel,rname,remail;
	 public boolean isadmin;
	 public String cat,type,partnum;
	 public int moneyneeded;

	Database d=new Database();
	public addappmodel(String partnum,String aadn,String n,String t, String em,boolean  isad,String cat,String type,String rtel,String rname,String rem,int ina){
		this.name=n;
		this.tel=t;
		this.email=em;
		this.cat=cat;
		this.type=type;
		this.rname=rname;
		this.rtel=rtel;
		this.remail=rem;
       this.isadmin=isad;
       this.blockrealnum=aadn;
       this.partnum=partnum;
		//this.date=da;
       this.moneyneeded=ina;
	}
	public void insert(String username,String password) throws SQLException
	{
		int Bid=d.getid();
		if(Bid==-1)
		{
				 Alert a = new Alert(AlertType.NONE);
		  		  a.setAlertType(AlertType.ERROR);
		  		  a.setContentText("Block Doesnt Exist");
		           a.showAndWait();
		           return;
		}
		
		int ia;
		
		if(isadmin==false)
			ia=0;
		else {
			ia=1;
			
		}
		int ca=d.getcode(cat);
		int ct=d.getcode(type);
		this.moneyneeded=d.getmoney(ca);
		if(d.insertapp(partnum,Bid,blockrealnum, name, tel, email,ia,ca,ct,username, password,rname,rtel,remail,moneyneeded)==true)
		{
			Alert a = new Alert(AlertType.NONE);
	  		  a.setAlertType(AlertType.INFORMATION);
	  		  a.setContentText("Owner Added!");
	           a.show();
		}
	} 
 
	public void update(String oldname,String oldpartnum,String username,String password) throws SQLException {
		int Bid=d.getid();
		if(Bid==-1)
		{
				 Alert a = new Alert(AlertType.NONE);
		  		  a.setAlertType(AlertType.ERROR);
		  		  a.setContentText("Block Doesnt Exist");
		           a.show();
		           return;
		}
		int ia;
		
		if(isadmin==false)
			ia=0;
		else {
			ia=1;
			
		}
		int ca=d.getcode(cat);
		int ct=d.getcode(type);
		this.moneyneeded=d.getmoney(ca);
		if(d.updateapp(oldname,oldpartnum,partnum,Bid,blockrealnum, name, tel, email,ia,ca,ct,username, password,rname,rtel,remail,moneyneeded)==true)
		{
			Alert a = new Alert(AlertType.NONE);
	  		  a.setAlertType(AlertType.INFORMATION);
	  		  a.setContentText("Owner Updated!");
	           a.show();
		}
		
	}
	
	public String getBlockrealnum() {
		return blockrealnum;
	}
	public String getRtel() {
		return rtel;
	}
	public String getRname() {
		return rname;
	}
	public String getRemail() {
		return remail;
	}

	
	public String getType() {
		return type;
	}
	public String getCat() {
		return cat;
	}
	public String getName() {
		return name;
	}


	public String getTel() {
		return tel;
	}


	public String getEmail() {
		return email;
	}


	public String getDate() {
		return date;
	}


	public boolean getIsadmin() {
		return isadmin;
	}

	public String getPartnum()
	{
		return partnum;
	}
	public int getMoneyneeded() {
		return moneyneeded;
	}

	
}
