package Models;

import java.sql.SQLException;

import application.Database;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class addblockmodel {


	 
	 Database d=new Database();
	
	
	String bname,totalmoney,brn;
	 
	 public addblockmodel(String brn,String bname,String Totalmoney)
	 {
		 this.brn=brn;
		 this.bname=bname;
		 this.totalmoney=Totalmoney;
	 }
	 public void insert() throws SQLException
		{
			
			if(d.insertBlock(brn,bname,Integer.parseInt(totalmoney))==true)
			{
				Alert a = new Alert(AlertType.NONE);
		  		  a.setAlertType(AlertType.INFORMATION);
		  		  a.setContentText("Block Added!");
		           a.show();
			}
			
		} 
	 
	 public String getBrn() {
			return brn;
		}
	 
	public String getBname() {
		return bname;
	}
	public String getTotalmoney() {
		return totalmoney;
	}


	

	
}
