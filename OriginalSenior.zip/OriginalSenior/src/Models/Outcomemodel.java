package Models;


import java.io.File;
import java.sql.SQLException;
import application.Database;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;


public class Outcomemodel {

	Database d=new Database();
	String bname, amount, type;
	String date,to,partnum,cat;
	String  file,name;
	public int id=loginmodel.getid();
	public Outcomemodel(String partnum,String name,String a,String to,String cat,String t,String d2,String f) {
		// TODO Auto-generated constructor stub
		this.partnum=partnum;
		this.cat=cat;
		this.amount=a;
		this.to=to;
		this.file=f;
		this.type=t;
		this.date=d2;
		this.name=name;
	}
	public void insert()
	{
		int m;
		try {
			 bname=d.getbname();
			m=d.getTotalmoney(bname);
			
			 if(m<Integer.parseInt(amount))
			{
				 Alert a = new Alert(AlertType.NONE);
		  		  a.setAlertType(AlertType.ERROR);
		  		  a.setContentText("NO ENOUGH MONEY!!");
		           a.show();
		           return;
			}
			else {
				d.subtotal(bname,Integer.parseInt(amount));
				int c=d.getcode(cat);
				int t=d.getcode(type);
				if(d.insertOutcome(' ',partnum,name,amount,to, c,t, date,file))
				{
					Alert a = new Alert(AlertType.NONE);
			  		  a.setAlertType(AlertType.INFORMATION);
			  		  a.setContentText("Outcome Added!");
			           a.show();
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void update(String oldname,String oldamount)
	{
		int m;
		try {
			 bname=d.getbname();
			m=d.getTotalmoney(bname);
			
			 if(m<Integer.parseInt(amount))
			{
				 Alert a = new Alert(AlertType.NONE);
		  		  a.setAlertType(AlertType.ERROR);
		  		  a.setContentText("NO ENOUGH MONEY!!");
		           a.show();
		           return;
			}
			else {
				d.addtototal(bname, Integer.parseInt(oldamount));
				d.subtotal(bname,Integer.parseInt(amount));
				int c=d.getcode(cat);
				int t=d.getcode(type);
				if(d.updateOutcome(oldname,' ',partnum,name,amount,to, c,t, date,file))
				{
					Alert a = new Alert(AlertType.NONE);
			  		  a.setAlertType(AlertType.INFORMATION);
			  		  a.setContentText("Outcome Updated!");
			           a.show();
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public Database getD() {
		return d;
	}

	public String getBname() {
		return bname;
	}

	public String getAmount() {
		return amount;
	}

	public String getType() {
		return type;
	}

	public String getDate() {
		return date;
	}

	public String getTo() {
		return to;
	}


	public String getPartnum() {
		return partnum;
	}
	public String getName() {
		return name;
	}
	public String getCat() {
		return cat;
	}
//	public int getId() {
//		return id;
//	}
	public String getFile() {
		return file;
	}
	
}
