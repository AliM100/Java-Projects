package Models;


import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import application.report;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.print.Collation;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class reportmodel {

	application.Database d=new application.Database();
	public ObservableList<application.report> list = FXCollections.observableArrayList();
	
	
	
	public ObservableList  list(String ca,ObservableList cat, String D1,String D2) throws SQLException {
		ArrayList <String> a=new ArrayList<String>();
		int c=d.getcode(cat.get(0).toString());
		int cc=d.getcode(ca.toString());
		String t=d.getT(c);
		String tt=d.getT(cc);
		if(d.getDesc(c).equals("All"))
		{
			a=d.getlistcat(tt,D1,D2);
			for(int j=0;j<a.size();j++) {
				int c1=d.getcode(a.get(j).toString());
				String t1=d.getT(c1);
				System.out.println("in model "+t1);
				System.out.println(a.get(j).toString());
				list.add(d.getreportincome(t1,c1,D1,D2));
			}
		}else {
			for(int i=0;i<cat.size();i++)
			{
				 c=d.getcode(cat.get(i).toString());
				 cc=d.getcode(ca.toString());
				 t=d.getT(c);
				 tt=d.getT(cc);
				list.add(d.getreportincome(t,c,D1,D2));
				
			}
		}
		
		return list;
	}



	public void export() throws IOException
	{
		XSSFWorkbook wb=new XSSFWorkbook();
    	XSSFSheet sheet=wb.createSheet("Report");
    	XSSFRow  header=sheet.createRow(0);
    	header.createCell(2).setCellValue("Amount");
    
    	
    	header.createCell(0).setCellValue("Category");
    	header.createCell(1).setCellValue("Sub Category");
    	
    	for(int i=0;i<list.size();i++)
    	{
    		XSSFRow row=sheet.createRow(i+1);
    		row.createCell(2).setCellValue(list.get(i).getTotal());
    		row.createCell(0).setCellValue(list.get(i).getCat());
    		row.createCell(1).setCellValue(list.get(i).getSubcat());
    		
    	}
    	FileOutputStream fileOut=new FileOutputStream("Report.xlsx");
    	wb.write(fileOut);
    	fileOut.close();
    	Alert alert=new Alert(AlertType.INFORMATION);
    	alert.setTitle("Information Dialog");
    	alert.setHeaderText(null);
    	alert.setContentText("Report Exported in Excel.");
    	alert.showAndWait();
	}
}
