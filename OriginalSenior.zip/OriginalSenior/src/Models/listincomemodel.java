package Models;


import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class listincomemodel {

	application.Database d=new application.Database();
	public ObservableList<Models.Incomemodel> list = FXCollections.observableArrayList();
	public ObservableList  list(String cat, String D1,String D2) throws SQLException {
		
		int c=d.getcode(cat);
		list=d.getlistIncome(c,D1, D2);
		
		return list;
	}
	
	public void export() throws IOException
	{
		XSSFWorkbook wb=new XSSFWorkbook();
    	XSSFSheet sheet=wb.createSheet("Income List");
    	XSSFRow  header=sheet.createRow(0);
    	header.createCell(0).setCellValue("Amount");
    	header.createCell(1).setCellValue("Partnum");
    	header.createCell(2).setCellValue("From");
    	header.createCell(3).setCellValue("Category");
    	header.createCell(4).setCellValue("Type");
    	header.createCell(5).setCellValue("Date");
    	for(int i=0;i<list.size();i++)
    	{
    		XSSFRow row=sheet.createRow(i+1);
    		row.createCell(0).setCellValue(list.get(i).getAmount());
    		row.createCell(1).setCellValue(list.get(i).getPartnum());
    		row.createCell(2).setCellValue(list.get(i).getFrom());
    		row.createCell(3).setCellValue(list.get(i).getCat());
    		row.createCell(4).setCellValue(list.get(i).getType());
    		row.createCell(5).setCellValue(list.get(i).getDate());
    	}
    	FileOutputStream fileOut=new FileOutputStream("Income List.xlsx");
    	wb.write(fileOut);
    	fileOut.close();
    	Alert alert=new Alert(AlertType.INFORMATION);
    	alert.setTitle("Information Dialog");
    	alert.setHeaderText(null);
    	alert.setContentText("Income List Exported in Excel.");
    	alert.showAndWait();
	}
}
