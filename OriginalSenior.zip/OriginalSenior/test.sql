USE [senior]
GO
USE [login]
GO
INSERT INTO APARTMENTOWNER
         
     VALUES
           (1,'G12',1,53,'admin','0300000','a@gmail.com',1,1010000,1020000,'admin',123,'','','')
GO



		SELECT * 
		   FROM APARTMENTOWNER ;
                
SELECT * 
   FROM outcomes ;


   SELECT * 
   FROM incomes ;
 


     SELECT * 
   FROM BLOCK ;

    SELECT * 
   FROM coding ;

 Insert into Other  values(1,'flower','080000','flower@gmail.com','store',0,'flower',123)

				 SET IDENTITY_INSERT Block ON
           	  Insert into Block  values(1,null,null)
			   SET IDENTITY_INSERT Block  OFF
				
			   Drop Database senior
			   Go
			   Drop table Outcomes

			   Select OUNAME,OUAMOUNT,OUFROM,OUTO,OUTYPE,OUD from Outcomes where OUD>='2021-08-1' and OUD<='2021-08-1'

			   Select INAME,IAMOUNT,IFROM,ITO,ITYPE,IDA from incomes where IDA>='2021-08-1' and IDA<='2021-09-1'



			   Select aoo.AONAME,o.ONAME From other as o ,APARTMENTOWNER as aoo where aoo.AONAME='flower'or o.ONAME='flower'

			   if(aoo.AONAME=='flower')
			   BEGIN
			   UPDATE  APARTMENTOWNER 
			   set aoo.AOPAY=1
			   end
			   else 
			   BEGIN
			   UPDATE  other 
			   set OPAY=1
			   end
		UPDATE BLOCK set TOTALMONEY=1000
		 UPDATE  other 
			   set OPAY=0
			   where ONAME='closthstore'
		
			    UPDATE  apartmentowner 
			   set AOPAY=1
			   where AOname='flower'	 

			   Select a.AONAME,a.AOTEL,a.AOEMAIL,a.AOISADMIN,a.AOPAY,i.IDA from apartmentowner as a,incomes as i where i.IDA>='2021-08-1' and i.IDA<='2021-09-1' and i.IFROM=a.AONAME

			   delete from Outcomes where OUFROM='b4'
			   delete  from Block  where Blockid in (2,3) 
			

			   insert into coding values(1050000,'Income Amount',1,'INA');

			   delete from coding where level =2
			  delete from apartmentowner where AONAME='www'
			   ADD  T varchar(255)

			   Update coding 
			   set T='Out' where code='1010000'
			      select * from coding where  level=2 and T in ('A',''); 
				   select * from coding where  TA 


				  Select * from coding where desc_='Apartment'


				  insert into coding 
				  insert into BLOCK values(53,'b1',0);

				  delete from APARTMENTOWNER where AOID in (10,18,19,20)
				   Update Block 
				   set TotalMONEY=400


				  Insert into APARTMENTOWNER    values  ('G53',1,53,'sami','03111111','s@gmail.com',1,1010000,2010000,'ab',123,'','','')
				Alter Table coding
				ADD MONEY integer

				Alter Table APARTMENTOWNER
				ADD   AOINCOMEAMOUNT  integer
				UPDATE APARTMENTOWNER
				set AOINCOMEAMOUNT=150
				where Aopartnum='G12'

				Insert into Outcomes    values  ('','',0,220,'hhh',3040002,2050000,'2021-09-16','');

				delete from coding where CODE in (20200022)

				Update coding set T ='AllOut' where CODE in (3040003)