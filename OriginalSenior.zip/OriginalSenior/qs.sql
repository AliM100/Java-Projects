/*==============================================================*/
/* DBMS name:      SAP SQL Anywhere 17                          */
/* Created on:     8/30/2021 11:52:05 PM                        */
/*==============================================================*/



drop index if exists APARTMENTOWNER.IN_FK;

drop index if exists APARTMENTOWNER.APARTMENTOWNER_PK;

drop table if exists APARTMENTOWNER;

drop index if exists BLOCK.BLOCK_PK;

drop table if exists BLOCK;

drop index if exists CODING.CODING_PK;

drop table if exists CODING;

drop index if exists INCOMES.MAN_FK;

drop index if exists INCOMES.INCOMES_PK;

drop table if exists INCOMES;

drop index if exists OUTCOMES.MANA_FK;

drop index if exists OUTCOMES.OUTCOMES_PK;

drop table if exists OUTCOMES;

/*==============================================================*/
/* Table: APARTMENTOWNER                                        */
/*==============================================================*/
create  table APARTMENTOWNER 
(
   AOID                 integer                        not null identity(1,1),
   AOPARTNUM            varchar(255)                    not null,
   BLOCKID              integer                        not null,
   BREALESTATENUMBER    integer                        not null,
   AONAME               varchar(255)                   null,
   AOTEL                varchar(255)                   null,
   AOEMAIL              varchar(255)                   null,
   AOISADMIN            integer                       null,
   AOCAT                integer                        null,
   AOTYPE               integer                        null,
   AOUSERNAME           varchar(255)                   null,
   AOPASSWORD           varchar(255)                   null,
   AORNAME              varchar(255)                   null,
   AORTEL               varchar(255)                   null,
   AOREMAIL             varchar(255)                   null,
   AOINCOMEAMOUNT		integer						   null,
   constraint PK_APARTMENTOWNER primary key clustered (AOID, AOPARTNUM)
);

/*==============================================================*/
/* Index: APARTMENTOWNER_PK                                     */
/*==============================================================*/
create unique clustered index APARTMENTOWNER_PK on APARTMENTOWNER (
AOID ASC,
AOPARTNUM ASC
);

/*==============================================================*/
/* Index: IN_FK                                                 */
/*==============================================================*/
create index IN_FK on APARTMENTOWNER (
BLOCKID ASC,
BREALESTATENUMBER ASC
);

/*==============================================================*/
/* Table: BLOCK                                                 */
/*==============================================================*/
create  table BLOCK 
(
   BLOCKID              integer                        not null identity(1,1),
   BREALESTATENUMBER    integer                        not null,
   BLOCKNAME            varchar(255)                   null,
   TOTALMONEY           integer                        null,
   constraint PK_BLOCK primary key clustered (BLOCKID, BREALESTATENUMBER)
);

/*==============================================================*/
/* Index: BLOCK_PK                                              */
/*==============================================================*/
create unique clustered index BLOCK_PK on BLOCK (
BLOCKID ASC,
BREALESTATENUMBER ASC
);

/*==============================================================*/
/* Table: CODING                                                */
/*==============================================================*/
create  table CODING 
(
   CODE                 integer                        not null,
   DESC_                varchar(255)                   null,
   LEVEL                integer                        null,
   T                     varchar(255)                   null,
   MONEY				integer							 null,
   constraint PK_CODING primary key clustered (CODE)
);

/*==============================================================*/
/* Index: CODING_PK                                             */
/*==============================================================*/
create unique clustered index CODING_PK on CODING (
CODE ASC
);

/*==============================================================*/
/* Table: INCOMES                                               */
/*==============================================================*/
create  table INCOMES 
(
   INCOMEID             integer                        not null identity(1,1),
   AOID                 integer                        null,
   AOPARTNUM            varchar(255)                         null,
   INAME                varchar(255)                   null,
   IAMOUNT              integer                        null,
   IFROM                varchar(255)                   null,
   ICAT                 integer                        null,
   ITYPE                integer                        null,
   IDA                  date                           null,
   constraint PK_INCOMES primary key clustered (INCOMEID)
);

/*==============================================================*/
/* Index: INCOMES_PK                                            */
/*==============================================================*/
create unique clustered index INCOMES_PK on INCOMES (
INCOMEID ASC
);

/*==============================================================*/
/* Index: MAN_FK                                                */
/*==============================================================*/
create index MAN_FK on INCOMES (
AOID ASC,
AOPARTNUM ASC
);

/*==============================================================*/
/* Table: OUTCOMES                                              */
/*==============================================================*/
create  table OUTCOMES 
(
   OUTCOMEID            integer                        not null identity(1,1),
   AOID                 integer                        null,
   AOPARTNUM            varchar(255)                         null,
   OUNAME               varchar(255)                   null,
   OUAMOUNT             integer                        null,
   OUTO               varchar(255)                   null,
   OCAT                 integer                        null,
   OUTYPE               integer                        null,
   OUD                  date                           null,
   ODOC                 varchar(255)                         null,
   constraint PK_OUTCOMES primary key clustered (OUTCOMEID)
);

/*==============================================================*/
/* Index: OUTCOMES_PK                                           */
/*==============================================================*/
create unique clustered index OUTCOMES_PK on OUTCOMES (
OUTCOMEID ASC
);

/*==============================================================*/
/* Index: MANA_FK                                               */
/*==============================================================*/
create index MANA_FK on OUTCOMES (
AOID ASC,
AOPARTNUM ASC
);

alter table APARTMENTOWNER
   add constraint FK_APARTMEN_IN_BLOCK foreign key (BLOCKID, BREALESTATENUMBER)
      references BLOCK (BLOCKID, BREALESTATENUMBER)
      on update CASCADE
      on delete CASCADE;

alter table INCOMES
   add constraint FK_INCOMES_MAN_APARTMEN foreign key (AOID, AOPARTNUM)
      references APARTMENTOWNER (AOID, AOPARTNUM)
      on update CASCADE
      on delete CASCADE;

alter table OUTCOMES
   add constraint FK_OUTCOMES_MANA_APARTMEN foreign key (AOID, AOPARTNUM)
      references APARTMENTOWNER (AOID, AOPARTNUM)
      on update CASCADE
      on delete CASCADE;